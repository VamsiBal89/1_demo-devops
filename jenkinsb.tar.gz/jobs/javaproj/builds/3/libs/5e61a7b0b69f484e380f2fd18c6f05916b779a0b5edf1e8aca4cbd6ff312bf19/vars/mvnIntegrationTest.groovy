def call(){
    sh 'mvn verify -DskipUnitTests'
}